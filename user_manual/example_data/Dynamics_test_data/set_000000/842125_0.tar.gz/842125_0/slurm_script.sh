#!/bin/bash
#SBATCH -J Excimontec # Job name
#SBATCH -p preemptible
#SBATCH -n 48 # Number of tasks
#SBATCH -t 04:00:00 # Maximum walltime
#SBATCH -c 1 # Number of cpus per task
#SBATCH --mem=64000
#SBATCH --exclude=n634,n635,n636,n681,n682,n685,n686,n687,n702,n703,n1321,n1322,n1323,n1324,n1325,n1326,n1327,n1328,n1329,n1330,n1331,n1333,n1334,n1336,n1367,n1370,n1371,n1372,n1411,n1412,n1413,n1414,n1415,n1416,n1417,n1418,n1419
#SBATCH --mail-type=FAIL,END
#SBATCH --mail-user=michael.heiber@nist.gov

# Get Version Number
read -r version_num < Excimontec_version.txt

# Setup Job Directory
mkdir -p ${SLURM_ARRAY_JOB_ID}_${SLURM_ARRAY_TASK_ID}
cd ${SLURM_ARRAY_JOB_ID}_${SLURM_ARRAY_TASK_ID}
cp ~/Excimontec/$version_num/Excimontec.exe ./
cp ../parameters_${SLURM_ARRAY_TASK_ID}.txt ./parameters.txt
if [ -d "../Morphology_Files" ]
then
    cp ../Morphology_Files/morphology* ./
fi
cp ../slurm_script.sh ./
cp ../sweep_script.sh ./

# Run the simulation
#mpiexec --mca mpi_cuda_support 0 -n 96 Excimontec.exe parameters.txt > output.txt
mpiexec -n 48 Excimontec.exe parameters.txt > output.txt

# Clean Up
if [ -d "../Morphology_Files" ]
then
    rm -f ./morphology*
    cp ../Morphology_Files/morphology*_info.txt ./
fi
rm -f Excimontec.exe

# Compress and copy results to results folder
cd ..
tar -zcf ${SLURM_ARRAY_JOB_ID}_${SLURM_ARRAY_TASK_ID}.tar.gz ${SLURM_ARRAY_JOB_ID}_${SLURM_ARRAY_TASK_ID}
mkdir -p ~/Excimontec/$version_num/results
cp ${SLURM_ARRAY_JOB_ID}_${SLURM_ARRAY_TASK_ID}.tar.gz ~/Excimontec/$version_num/results/

# Final clean up
rm -f ${SLURM_ARRAY_JOB_ID}_${SLURM_ARRAY_TASK_ID}.tar.gz
rm -rf ${SLURM_ARRAY_JOB_ID}_${SLURM_ARRAY_TASK_ID}