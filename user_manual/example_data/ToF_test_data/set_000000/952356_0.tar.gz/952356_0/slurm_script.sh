#!/bin/bash
#SBATCH -J Excimontec # Job name
#SBATCH -p preemptible
#SBATCH -n 96 # Number of tasks
#SBATCH -t 24:00:00 # Maximum walltime
#SBATCH -c 1 # Number of cpus per task
#SBATCH --mem=64000
#SBATCH --mail-type=FAIL,END
#SBATCH --mail-user=michael.heiber@nist.gov

# Get Version Number
read -r version_num < Excimontec_version.txt
read -r set_num < Set_number.txt

# Setup Job Directory
mkdir -p ${SLURM_ARRAY_JOB_ID}_${SLURM_ARRAY_TASK_ID}
cd ${SLURM_ARRAY_JOB_ID}_${SLURM_ARRAY_TASK_ID}
cp ~/Excimontec/$version_num/Excimontec.exe ./
cp ../parameters_${SLURM_ARRAY_TASK_ID}.txt ./parameters.txt
if [ -d "../Morphology_Files" ]
then
    cp ../Morphology_Files/morphology* ./
fi
cp ../slurm_script.sh ./
cp ../sweep_script.sh ./

# Run the simulation
mpiexec -n 96 Excimontec.exe parameters.txt > output.txt

# Clean Up
if [ -d "../Morphology_Files" ]
then
    rm -f ./morphology*
    cp ../Morphology_Files/morphology*_info.txt ./
fi
rm -f Excimontec.exe

# Compress and copy results to results folder
cd ..
tar -zcf ${SLURM_ARRAY_JOB_ID}_${SLURM_ARRAY_TASK_ID}.tar.gz ${SLURM_ARRAY_JOB_ID}_${SLURM_ARRAY_TASK_ID}
mkdir -p ~/Excimontec/$version_num/results/$set_num/
cp ${SLURM_ARRAY_JOB_ID}_${SLURM_ARRAY_TASK_ID}.tar.gz ~/Excimontec/$version_num/results/$set_num/

# Final clean up
rm -f ${SLURM_ARRAY_JOB_ID}_${SLURM_ARRAY_TASK_ID}.tar.gz
rm -rf ${SLURM_ARRAY_JOB_ID}_${SLURM_ARRAY_TASK_ID}