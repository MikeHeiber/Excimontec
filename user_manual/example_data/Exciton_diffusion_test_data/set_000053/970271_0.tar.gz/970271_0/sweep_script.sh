#!/bin/bash

# Variable Definition
version_num=v1.0.0-rc.1
morphology_version_num=v4.0.2
ScriptNum=5
MorphologyNum=$1
ParamNum_i=$2
SetNum=$3

# Define Parameter Sweep
var_name=Energy_stdev_donor
vals=(0.038 0.051 0.064 0.077 0.089 0.102)
num_vals=${#vals[*]}

# Setup Working Directory
printf -v exec_time '%(%s)T' -1
cd /wrk/mch2
mkdir $exec_time
WorkingDir=/wrk/mch2/$exec_time
cd $WorkingDir
touch Excimontec_version.txt
printf "$version_num" >> Excimontec_version.txt
touch Morphology_version.txt
printf "$morphology_version_num" >> Morphology_version.txt
touch Morphology_number.txt
printf "$MorphologyNum" >> Morphology_number.txt
touch Set_number.txt
printf "$SetNum" >> Set_number.txt
cp ~/Excimontec/$version_num/slurm_script$ScriptNum.sh ./slurm_script.sh
cp ~/Excimontec/$version_num/${0##*/} ./sweep_script.sh
cp ~/Excimontec/$version_num/restart_script.sh ./

# Setup Morphology and Parameter Files
if [ "$MorphologyNum" != "none" ]
then
    cp ~/Ising_OPV/$morphology_version_num/results/${MorphologyNum}.tar.gz ./
    tar -xzf ${MorphologyNum}.tar.gz
    mkdir -p Morphology_Files
    cp ./$MorphologyNum/morphology* ./Morphology_Files/
    cp ./$MorphologyNum/analysis_summary* ./Morphology_Files/morphology_${MorphologyNum}_info.txt
    rm -f ${MorphologyNum}.tar.gz
    rm -rf ${MorphologyNum}
fi

for index in ${!vals[*]}
do
    cp ~/Excimontec/$version_num/parameter_files/parameters_${ParamNum_i}.txt ./parameters_${index}.txt
    sed -i "/$var_name/ { c \
    ${vals[$index]} //$var_name
    }" ./parameters_${index}.txt
done

sbatch --array=0-$((num_vals-1)) --constraint="mlx" slurm_script.sh